<?php
define( 'DB_NAME', 'demo_wp' );
define( 'DB_USER', 'demo_wpuser' );
define( 'DB_PASSWORD', 'old-secret-password' );
define( 'DB_HOST', 'localhost' );
$table_prefix = 'wp_';
require_once ABSPATH . 'wp-settings.php';
