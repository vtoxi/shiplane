CREATE TABLE `orders` (`id` int NOT NULL AUTO_INCREMENT, `total` decimal(10,2), PRIMARY KEY (`id`));
INSERT INTO `orders` VALUES (1, 19.90), (2, 42.00);
