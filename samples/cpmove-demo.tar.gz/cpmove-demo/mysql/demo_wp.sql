-- Sample WordPress dump
CREATE TABLE `wp_options` (`option_id` bigint unsigned NOT NULL AUTO_INCREMENT, `option_name` varchar(191) NOT NULL, `option_value` longtext NOT NULL, PRIMARY KEY (`option_id`));
INSERT INTO `wp_options` VALUES (1,'siteurl','https://demo-blog.example'),(2,'blogname','Demo Blog');
CREATE TABLE `wp_posts` (`ID` bigint unsigned NOT NULL AUTO_INCREMENT, `post_title` text NOT NULL, PRIMARY KEY (`ID`));
INSERT INTO `wp_posts` VALUES (1,'Hello world!');
