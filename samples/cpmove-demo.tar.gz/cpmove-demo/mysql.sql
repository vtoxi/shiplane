GRANT ALL PRIVILEGES ON `demo_wp`.* TO 'demo_wpuser'@'localhost';
GRANT ALL PRIVILEGES ON `demo_shop`.* TO 'demo_shopuser'@'localhost';
