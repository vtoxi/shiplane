<?php // WordPress front controller
require __DIR__ . "/wp-blog-header.php";
